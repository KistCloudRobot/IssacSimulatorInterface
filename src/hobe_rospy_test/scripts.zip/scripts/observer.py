import rospy
from tf2_msgs.msg import TFMessage
from tf.transformations import euler_from_quaternion
from value import RobotID


class Observer:
    def __init__(self, robotController):
        self.robotController = robotController
        rospy.Subscriber("/AMR_LIFT01_pose", TFMessage, self.newLift1Pos)
        rospy.Subscriber("/AMR_LIFT02_pose", TFMessage, self.newLift2Pos)

    def newLift1Pos(self, msg):
        transform = msg.transforms[0].transform
        rot_q = transform.rotation
        (roll, pitch, euler_theta) = euler_from_quaternion([rot_q.x, rot_q.y, rot_q.z, rot_q.w])
        robot_name = RobotID.AMR_LIFT01
        self.robotController.changeRobotStatus(robot_name, transform.translation.x, transform.translation.y, euler_theta)

    def newLift2Pos(self, msg):
        transform = msg.transforms[0].transform
        rot_q = transform.rotation
        (roll, pitch, euler_theta) = euler_from_quaternion([rot_q.x, rot_q.y, rot_q.z, rot_q.w])
        robot_name = RobotID.AMR_LIFT02
        self.robotController.changeRobotStatus(robot_name, transform.translation.x, transform.translation.y, euler_theta)