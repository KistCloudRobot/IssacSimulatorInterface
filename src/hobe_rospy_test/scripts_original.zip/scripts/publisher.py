import threading
import time
import threadHandler
from communication.messageFactory import MessageFactory

class Publisher:
    def __init__(self, adaptor, robots):
        self.adaptor = adaptor
        self.robots = robots
        self.thread = threading.Thread(target=self.run, daemon=True)

    def start(self):
        self.thread.run()

    def run(self):
        while not threadHandler.exit_event.isSet():
            time.sleep(1)
            for robot in self.robots.values():
                message = MessageFactory.newRTSRMessage(robot.name, robot.status, robot.pos[0], robot.pos[2], robot.theta, robot.speed.linear.x, robot.battery, robot.loading)
                self.adaptor.broadcast(message)
