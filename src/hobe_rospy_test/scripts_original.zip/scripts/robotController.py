import threading
import time

import threadHandler
from communication.adaptor import Adaptor
from communication.messageFactory import MessageFactory
from service.service import *
from robotProxy import RobotProxy
from observer import Observer
from publisher import Publisher
from value import ServiceResult, RobotID


class RobotController:
    def __init__(self):
        self.adaptor = Adaptor(self)
        self.robots = {
            RobotID.AMR_LIFT01: RobotProxy(RobotID.AMR_LIFT01),
            RobotID.AMR_LIFT02: RobotProxy(RobotID.AMR_LIFT02)
        }
        self.observer = Observer(self)
        self.publisher = Publisher(self.adaptor, self.robots)
        self.serviceQueue = list()
        self.runThread = threading.Thread(target=self.run)
        threadHandler.threads.append(self.runThread)

    def start(self):
        self.adaptor.start()
        self.runThread.start()
        self.publisher.start()

    def run(self):
        while not threadHandler.exit_event.isSet():
            time.sleep(0.15)
            if len(self.serviceQueue) > 0:
                self.serviceReceived(self.serviceQueue.pop())

            for robot in self.robots.values():
                result = robot.execute()
                if result:
                    self.serviceFinished(robot.service)
                    robot.setService(None)

    def serviceReceived(self, service):
        if isinstance(service, LoginService):
            ackMessage = MessageFactory.newAckMessage(service)
            self.adaptor.broadcast(ackMessage)
            service.setResult(ServiceResult.Success)
            self.serviceFinished(service)
        elif isinstance(service, RobotService):
            self.robots[service.robotName].setService(service)
            ackMessage = MessageFactory.newAckMessage(service)
            self.adaptor.broadcast(ackMessage)
            if service.result is not None:
                self.serviceFinished(service)

    def serviceFinished(self, service):
        ackEndMessage = MessageFactory.newAckEndMessage(service)
        self.adaptor.broadcast(ackEndMessage)

    def changeRobotStatus(self, robotName, x, y, theta):
        robot = self.robots[robotName]
        robot.pos[0] = x
        robot.pos[2] = y
        robot.theta = theta
        # if robotName == 'AMR_LIFT02':
        print('{} - {} - {}'.format(robotName,robot.pos,robot.theta))

if __name__ == '__main__':
    rc = RobotController()
    rc.start()
    while True:
        pass
