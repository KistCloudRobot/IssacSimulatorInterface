#!/usr/bin/env python
# Copyright (c) 2020-2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import rospy
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Twist
import numpy as np
import time

rospy.init_node("test_rosbridge", anonymous=True)

pub_1 = rospy.Publisher("/AMR_LIFT01_cmd_vel", Twist, queue_size=10)

pub_2 = rospy.Publisher("/AMR_LIFT02_cmd_vel", Twist, queue_size=10)

pub_3 = rospy.Publisher("/AMR_LIFT03_cmd_vel", Twist, queue_size=10)
pub_4 = rospy.Publisher("/AMR_LIFT04_cmd_vel", Twist, queue_size=10)



# position control the robot to wiggle around each joint
time_start = time.time()
rate = rospy.Rate(20)
rate.sleep(10)
while not rospy.is_shutdown():
    twist = Twist()
    twist.linear.x = 1 * 2
    twist.linear.y = 0 * 2
    twist.linear.z = 0 * 2
    twist.angular.x = 0
    twist.angular.y = 0
    twist.angular.z = 0 #self.th * self.turn
    pub_1.publish(twist)
    pub_2.publish(twist)
    pub_3.publish(twist)
    pub_4.publish(twist)
    

    rate.sleep(20)
