from enum import Enum


class RobotID(Enum):
    LOCAL = 0
    AMR_LIFT01 = 1
    AMR_LIFT02 = 2


class RobotStatus(Enum):
    Login = 0
    Ready = 1
    Move = 2
    Paused = 3
    Loading = 4
    Unloading = 5
    ChargeIn = 6
    ChargeOut = 7
    Charging = 8
    ChargeStopping = 9
    Error = 10
    EmergencyStop = 11
    GuideMove = 12
    PreciseMove = 13
    StraightBackMove = 14


class Direction(Enum):
    FORWARD = 0
    BACKWARD = 1


class ServiceType(Enum):
    Login = 0
    Move = 1
    GuideMove = 2
    PreciseMove = 3
    StraightBackMove = 4


class ServiceResult(Enum):
    Success = 0
    CannotAssignNewService = 3


class MessageType(Enum):
    RTSR = 0X53469DFD
    AckMove = 0X37911A75
    AckEndMove = 0X403A1BC4
    AckCancelMove = 0X4AB1FE2D
    AckEndCancelMove = 0X31F00931
    AckLoad = 0XC7C3BE2C
    AckEndLoad = 0X441C94CE
    AckUnload = 0X868F59B6
    AckEndUnload = 0X85D82ED1
    AckCharge = 0X9A427515
    AckEndCharge = 0X7F34A48F
    AckChargeStop = 0X3412A63E
    AckEndChargeStop = 0X06DE35AC
    AckPause = 0XD96EDE0B
    AckEndPause = 0X57295C2B
    AckResume = 0X1E8509B2
    AckEndResume = 0XBD2D122E
    AckDoorOpen = 0X71B2005B
    AckEndDoorOpen = 0XC9D2476A
    AckDoorClose = 0X70F29DDD
    AckEndDoorClose = 0X98378F4B
    PersonCall = 0XA88DA5FE
    AckLogin = 0X32BFB368
    AckEndLogin = 0X190ADBF8
    AckGuideMove = 0X6649B1A7
    AckEndGuideMove = 0X02655A11
    AckPreciseMove = 0X5E24BC2B
    AckEndPreciseMove = 0XB79B00DF
    AckStraightBackMove = 0X33446820
    AckEndStraightBackMove = 0X0DD13478
    ReqMove = 0X559657E8
    ReqCancelMove = 0X83EDC641
    ReqLoad = 0XF8957DC8
    ReqUnload = 0XF03739D3
    ReqCharge = 0X16B960EE
    ReqChargeStop = 0XCBC6486F
    ReqPause = 0X28EC89C1
    ReqResume = 0XE09AF0FB
    ReqDoorOpen = 0X078F486F
    ReqDoorClose = 0X4DDA0F69
    ReqLogin = 0X74A3BD60
    ReqGuideMove = 0XBEB3E9F1
    ReqPreciseMove = 0X168F1D9D
    ReqStraightBackMove = 0XACB2276E


if __name__ == '__main__':
    print(getattr(MessageType, "ReqPause"))
    print(MessageType["ReqPause"])
    print(MessageType(0XE09AF0FB))
    print(MessageType(0XE09AF0FB).name)
    print(hex(MessageType(0XE09AF0FB).value))
